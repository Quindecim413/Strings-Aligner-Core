#pragma once
#include "CachedData.h"
#include "DataGroup.h"

class ConcurrentSequenceAligner
{
public:
	const int maxThreads;
	void enqueHirshberg();
};

